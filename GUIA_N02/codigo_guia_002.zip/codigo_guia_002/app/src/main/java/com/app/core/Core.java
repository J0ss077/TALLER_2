/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.core;

import com.app.controllers.RegistroUsuario;

import com.app.models.Registro;

import java.io.IOException;

import java.util.Scanner;

/**
 *
 * @author Joss077
 */
public final class Core {
    
    private static Core MySelf; // Singleton

    public static Core Instance() {
        
        if (MySelf == null) {
            MySelf = new Core();
        }
        return MySelf; // Only one Instance
    }

    // -------------------------------------- //
    private final RegistroUsuario registroUsuario;
    
    private final Scanner scanner;
    
    private Core() {
        
        this.registroUsuario = RegistroUsuario.Instance();
        
        this.scanner = new Scanner(System.in);
    }
    
    public void Run() {
        
        int opcion = 0;
        
        while (true) {
            System.out.println("========== MENU CRUD USUARIO ==========");
            System.out.println("1. Agregar Registro");
            System.out.println("2. Editar Registro");
            System.out.println("3. Borrar Registro");
            System.out.println("4. Buscar Registro");
            System.out.println("5. Ver Todos los Registros");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opcion: ");
            
            try {
                opcion = Integer.parseInt(this.scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opcion invalida. Por favor, ingrese un número.");
                continue;
            }
            
            switch (opcion) {
                case 1 -> {
                    // Agregar Registro
                    try {
                        System.out.print("Ingrese ID: ");
                        int id = Integer.parseInt(this.scanner.nextLine());
                        System.out.print("Ingrese Nombre: ");
                        String nombre = this.scanner.nextLine();
                        System.out.print("Ingrese Email: ");
                        String email = this.scanner.nextLine();
                        System.out.print("Ingrese Telefono: ");
                        int telefono = Integer.parseInt(this.scanner.nextLine());
                        Registro nuevo = new Registro(id, nombre, email, telefono, true);
                        if (this.registroUsuario.AgregarRegistro(nuevo)) {
                            System.out.println("Registro agregado exitosamente.");
                        } else {
                            System.out.println("Error al agregar el registro.");
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("ID invalido.");
                    }
                }
                case 2 -> {
                    // Editar Registro
                    try {
                        System.out.print("Ingrese el ID del registro a editar: ");
                        int idEditar = Integer.parseInt(this.scanner.nextLine());
                        Registro registroEditar = this.registroUsuario.Buscar(Integer.toString(idEditar));
                        if (registroEditar != null) {
                            
                            System.out.print("Ingrese nuevo nombre: ");
                            String nuevoNombre = this.scanner.nextLine();
                            
                            System.out.print("Ingrese nuevo email: ");
                            String nuevoEmail = this.scanner.nextLine();
                            
                            System.out.print("Ingrese nuevo telefono: ");
                            int nuevoTelefono = Integer.parseInt(this.scanner.nextLine());
                            
                            registroEditar.setNombre(nuevoNombre);
                            registroEditar.setEmail(nuevoEmail);
                            registroEditar.setTelefono(nuevoTelefono);
                            
                            if (this.registroUsuario.EditarRegistro(registroEditar)) {
                                System.out.println("Registro editado exitosamente.");
                            } else {
                                System.out.println("Error al editar el registro.");
                            }
                        } else {
                            System.out.println("Registro no encontrado.");
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("ID invalido.");
                    }
                }
                case 3 -> {
                    // Borrar Registro
                    try {
                        System.out.print("Ingrese el ID del registro a borrar: ");
                        int idBorrar = Integer.parseInt(this.scanner.nextLine());
                        Registro registroBorrar = this.registroUsuario.Buscar(Integer.toString(idBorrar));
                        if (registroBorrar != null) {
                            if (this.registroUsuario.BorrarRegistro(registroBorrar)) {
                                System.out.println("Registro borrado exitosamente.");
                            } else {
                                System.out.println("Error al borrar el registro.");
                            }
                        } else {
                            System.out.println("Registro no encontrado.");
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("ID invalido.");
                    }
                }
                case 4 -> {
                    // Buscar Registro (por ID o Nombre)
                    System.out.print("Ingrese el ID o Nombre del registro a buscar: ");
                    String criterio = this.scanner.nextLine();
                    Registro encontrado = this.registroUsuario.Buscar(criterio);
                    if (encontrado != null) {
                        System.out.println("Registro encontrado: " + encontrado);
                    } else {
                        System.out.println("Registro no encontrado.");
                    }
                }
                case 5 -> {
                    // Ver Todos los Registros
                    try {
                        System.out.println("========== Listado de Registros ==========");
                        this.registroUsuario.VerTodos(); // Método extra implementado en RegistroUsuario
                    } catch (IOException e) {
                        System.out.println("Error al leer los registros.");
                        System.out.println(e.getMessage());
                    }
                }
                case 6 -> {
                    try (this.scanner) {
                        System.out.println("Saliendo del programa...");
                    }
                    System.exit(0);
                }
                
                default ->
                    System.out.println("Opcion no valida, intente nuevamente.");
            }
            System.out.println(); // Línea en blanco para separar iteraciones
        }
    }
}
