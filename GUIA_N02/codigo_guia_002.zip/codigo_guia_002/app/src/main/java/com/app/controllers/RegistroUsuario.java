/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.controllers;

import com.app.interfaces.GestionDatos;

import com.app.models.Registro;

import java.io.IOException;

import java.io.RandomAccessFile;

/**
 *
 * @author Joss077
 */
public final class RegistroUsuario implements GestionDatos {

    private static RegistroUsuario MySelf; // Singleton

    public static RegistroUsuario Instance() {

        if (MySelf == null) {
            MySelf = new RegistroUsuario();
        }
        return MySelf; // Only one Instance
    }

    // ------------------------------------------------- //
    private static final String FILE_NAME = "usuarios.dat";

    private RandomAccessFile raf;

    // Constantes para manejo de longitud fija
    private static final int TAM_NOMBRE = 20;
    private static final int TAM_EMAIL = 30;

    private RegistroUsuario() {

        try { // Init the random access data file...
            raf = new RandomAccessFile(FILE_NAME, "rw");
        } catch (IOException ex) { // Error loading...
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public boolean AgregarRegistro(Registro reg) {
        try {
            // Posicionar al final del archivo para agregar el registro
            raf.seek(raf.length());
            escribirRegistro(reg);
            return true;
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    @Override
    public boolean BorrarRegistro(Registro reg) {
        try {
            long pos = buscarPosicion(reg.getId());
            if (pos != -1) {
                // Posicionarse en el registro encontrado
                raf.seek(pos);
                Registro r = leerRegistro();
                // Marcar como inactivo (borrado lógico)
                r.setActivo(false);
                raf.seek(pos);
                escribirRegistro(r);
                return true;
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    @Override
    public boolean EditarRegistro(Registro reg) {
        try {
            long pos = buscarPosicion(reg.getId());
            if (pos != -1) {
                raf.seek(pos);
                escribirRegistro(reg);
                return true;
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    @Override
    public Registro Buscar(String criterio) {
        try {
            // Se intenta buscar por id (convertido a entero)
            int id = Integer.parseInt(criterio);
            raf.seek(0);
            while (raf.getFilePointer() < raf.length()) {
                Registro r = leerRegistro();
                if (r.getId() == id && r.isActivo()) {
                    return r;
                }
            }
        } catch (NumberFormatException e) {
            // Si criterio no es un número, se puede buscar por nombre (ejemplo)
            try {
                raf.seek(0);
                while (raf.getFilePointer() < raf.length()) {
                    Registro r = leerRegistro();
                    if (r.getNombre().trim().equalsIgnoreCase(criterio) && r.isActivo()) {
                        return r;
                    }
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public void VerTodos() throws IOException {
        // Se posiciona al inicio del archivo
        raf.seek(0);
        while (raf.getFilePointer() < raf.length()) {
            Registro r = leerRegistro();
            if (r.isActivo()) {
                System.out.println(r);
            }
        }
    }

    // Método auxiliar para buscar la posición de un registro según su id
    private long buscarPosicion(int id) throws IOException {
        raf.seek(0);
        while (raf.getFilePointer() < raf.length()) {
            long pos = raf.getFilePointer();
            Registro r = leerRegistro();
            if (r.getId() == id && r.isActivo()) {
                return pos;
            }
        }
        return -1;
    }

    // Escribe un registro en el archivo con formato de longitud fija
    private void escribirRegistro(Registro reg) throws IOException {
        raf.writeInt(reg.getId());
        // Escribir nombre con longitud fija
        String nombre = reg.getNombre();
        nombre = String.format("%-" + TAM_NOMBRE + "s", nombre);
        raf.writeChars(nombre);
        // Escribir email con longitud fija
        String email = reg.getEmail();
        email = String.format("%-" + TAM_EMAIL + "s", email);
        raf.writeChars(email);
        // Escribir el indicador de activo
        raf.writeBoolean(reg.isActivo());
    }

    // Lee un registro completo desde la posición actual del archivo
    private Registro leerRegistro() throws IOException {
        Registro reg = new Registro();
        reg.setId(raf.readInt());
        // Leer nombre
        char[] nombreChars = new char[TAM_NOMBRE];
        for (int i = 0; i < TAM_NOMBRE; i++) {
            nombreChars[i] = raf.readChar();
        }
        reg.setNombre(new String(nombreChars).trim());
        // Leer email
        char[] emailChars = new char[TAM_EMAIL];
        for (int i = 0; i < TAM_EMAIL; i++) {
            emailChars[i] = raf.readChar();
        }
        reg.setEmail(new String(emailChars).trim());
        reg.setActivo(raf.readBoolean());
        return reg;
    }
}
