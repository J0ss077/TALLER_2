/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.app.interfaces;

import com.app.models.Registro;

/**
 *
 * @author Joss077
 */
public interface GestionDatos {

    boolean AgregarRegistro(Registro reg);

    boolean BorrarRegistro(Registro reg);

    boolean EditarRegistro(Registro reg);

    Registro Buscar(String criterio);
}
