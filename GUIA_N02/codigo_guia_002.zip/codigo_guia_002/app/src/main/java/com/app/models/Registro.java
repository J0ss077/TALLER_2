/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.models;

/**
 *
 * @author Joss077
 */
public final class Registro {

    private int id;

    private String email;

    private String nombre;

    private boolean activo;

    public Registro() {
        // Registro
    }

    public Registro(int id, String nombre, String email, boolean activo) {

        this.id = id;

        this.email = email;

        this.nombre = nombre;

        this.activo = activo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "Registro{"
                + "id=" + id
                + ", email='" + email + '\''
                + ", nombre='" + nombre + '\''
                + ", activo=" + activo
                + '}';
    }
}
