package fecha;

import javax.swing.JOptionPane;

public class Fechas {

    public static void main(String[] args) {
        int dd = 0, mm = 0, aa = 0;
        Fecha f = new Fecha();
        do {

            dd = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite dia:"));
            mm = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite mes:"));

            do {
                aa = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite año:"));
            } while (aa < 1963);

            try {
                f.comprobar(dd, mm, aa);
            } catch (ExceptoFecha e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
                aa = mm = dd = 0;
            }

        } while (dd == 0 && mm == 0 && aa == 0);
        System.exit(0);
    }
}
