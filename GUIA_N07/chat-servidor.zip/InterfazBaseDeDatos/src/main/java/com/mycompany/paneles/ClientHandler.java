package com.mycompany.paneles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

class ClientHandler implements Runnable {

    private Socket socket;
    private BufferedReader bufreader;
    private BufferedWriter bufwriter;
    private final JTextArea areaTexto;
    public static List<ClientHandler> clientes = new ArrayList<>();

    public ClientHandler(Socket socket, JTextArea areaTexto) {
        this.socket = socket;
        this.areaTexto = areaTexto;
        try {
            bufreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufwriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            String mensajeRecibido;
            SwingUtilities.invokeLater(() -> {
                areaTexto.append("Usuario conectado\n");
            });
            while ((mensajeRecibido = bufreader.readLine()) != null) {
                String finalMensajeRecibido = mensajeRecibido;
                SwingUtilities.invokeLater(() -> {
                    areaTexto.append("Usuario: " + finalMensajeRecibido + "\n");
                });
                for (ClientHandler cliente : clientes) {
                    if (cliente != this) {
                        cliente.enviarMensaje(finalMensajeRecibido);
                    }
                }
                if (mensajeRecibido.equalsIgnoreCase("CHAO")) {
                    break;
                }
            }
            socket.close();
            bufreader.close();
            bufwriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void enviarMensaje(String mensaje) {
        try {
            bufwriter.write(mensaje + "\n");
            bufwriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
