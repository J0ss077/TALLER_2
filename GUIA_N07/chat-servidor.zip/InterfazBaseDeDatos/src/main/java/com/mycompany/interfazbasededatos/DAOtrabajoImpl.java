package com.mycompany.interfazbasededatos;

import com.mycompany.conection.conexion;
import com.mycompany.interfaces.DAOtrabajo;
import com.mycompany.models.Empleado;
import com.mycompany.models.Trabajo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOtrabajoImpl extends conexion implements DAOtrabajo {

    @Override
    public void registrar(Trabajo empleado) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("INSERT INTO trabajo (cedula_empleado, puesto, salario) VALUES (?, ?, ?);");
            st.setInt(1, empleado.getCedula_empleado());
            st.setString(2, empleado.getPuesto());
            st.setDouble(3, empleado.getSalario());
            st.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int cedula_empleado) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("DELETE FROM trabajo WHERE cedula_empleado = ?;");
            st.setInt(1, cedula_empleado);
            st.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Trabajo trabajo) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("UPDATE trabajo SET puesto = ?, salario = ? WHERE cedula_empleado = ?;");

            st.setString(1, trabajo.getPuesto());
            st.setDouble(2, trabajo.getSalario());
            st.setInt(3, trabajo.getCedula_empleado());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Trabajo> listatrabajos() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

  