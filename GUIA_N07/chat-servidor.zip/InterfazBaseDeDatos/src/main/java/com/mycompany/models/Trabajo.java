package com.mycompany.models;

public class Trabajo {

    private int cedula_empleado;
    private String puesto;
    private double salario;

    public int getCedula_empleado() {
        return cedula_empleado;
    }

    public void setCedula_empleado(int cedula_empleado) {
        this.cedula_empleado = cedula_empleado;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

}
