package com.mycompany.interfazbasededatos;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.mycompany.paneles.Actualizar;
import com.mycompany.paneles.Chat;
import com.mycompany.paneles.Eliminar;
import com.mycompany.paneles.Inicio;
import com.mycompany.paneles.añadir;
import com.mycompany.paneles.buscarUsuario;
import java.awt.BorderLayout;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author nicol
 */
public class JFrameFlatLaf extends javax.swing.JFrame {

    /**
     * Creates new form JFrameFlatLaf
     */
    public JFrameFlatLaf() {
        initComponents();
        temaDef();
        mostrarPanel(new Inicio());
    }

    private void temaDef() {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
            SwingUtilities.updateComponentTreeUI(this);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(JFrameFlatLaf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarPanel(JPanel p) {
        p.setSize(774, 520);
        p.setLocation(0, 0);

        contenido.setLayout(new BorderLayout());
        contenido.removeAll();
        contenido.add(p, BorderLayout.CENTER);
        contenido.revalidate();
        contenido.repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton6 = new javax.swing.JButton();
        panelFondo = new javax.swing.JPanel();
        panelButtons = new javax.swing.JPanel();
        inicioPanel = new javax.swing.JPanel();
        inicioButton = new javax.swing.JButton();
        createButton = new javax.swing.JButton();
        readButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        chatButton = new javax.swing.JButton();
        contenido = new javax.swing.JPanel();
        themesMenuBar = new javax.swing.JMenuBar();
        themesMenu = new javax.swing.JMenu();
        lightTButton = new javax.swing.JMenuItem();
        darkTButton = new javax.swing.JMenuItem();
        darculaTButton = new javax.swing.JMenuItem();
        intelliTButton = new javax.swing.JMenuItem();

        jButton6.setBackground(new java.awt.Color(141, 35, 15));
        jButton6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/user-delete_1_1.png"))); // NOI18N
        jButton6.setText("DELETE");
        jButton6.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        jButton6.setBorderPainted(false);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.setIconTextGap(23);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1013, 700));

        panelFondo.setBackground(new java.awt.Color(117, 177, 169));

        panelButtons.setBackground(new java.awt.Color(30, 67, 76));

        inicioPanel.setBackground(new java.awt.Color(204, 204, 204));

        inicioButton.setBackground(new java.awt.Color(255, 255, 255));
        inicioButton.setForeground(new java.awt.Color(102, 0, 0));
        inicioButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logo-umb.png"))); // NOI18N
        inicioButton.setBorder(null);
        inicioButton.setBorderPainted(false);
        inicioButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        inicioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inicioPanelLayout = new javax.swing.GroupLayout(inicioPanel);
        inicioPanel.setLayout(inicioPanelLayout);
        inicioPanelLayout.setHorizontalGroup(
            inicioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(inicioButton)
        );
        inicioPanelLayout.setVerticalGroup(
            inicioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(inicioButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        createButton.setBackground(new java.awt.Color(141, 35, 15));
        createButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        createButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/user-plus-svgrepo-com.png"))); // NOI18N
        createButton.setText("CREATE");
        createButton.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        createButton.setBorderPainted(false);
        createButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        createButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        createButton.setIconTextGap(10);
        createButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createButtonActionPerformed(evt);
            }
        });

        readButton.setBackground(new java.awt.Color(141, 35, 15));
        readButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        readButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/search.png"))); // NOI18N
        readButton.setText("READ");
        readButton.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        readButton.setBorderPainted(false);
        readButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        readButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        readButton.setIconTextGap(10);
        readButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readButtonActionPerformed(evt);
            }
        });

        updateButton.setBackground(new java.awt.Color(141, 35, 15));
        updateButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        updateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/update_1.png"))); // NOI18N
        updateButton.setText("UPDATE");
        updateButton.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        updateButton.setBorderPainted(false);
        updateButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        updateButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        updateButton.setIconTextGap(20);
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        deleteButton.setBackground(new java.awt.Color(141, 35, 15));
        deleteButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/user-delete_1_1.png"))); // NOI18N
        deleteButton.setText("DELETE");
        deleteButton.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        deleteButton.setBorderPainted(false);
        deleteButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        deleteButton.setIconTextGap(23);
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        chatButton.setBackground(new java.awt.Color(141, 35, 15));
        chatButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        chatButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/chat.png"))); // NOI18N
        chatButton.setText("CHAT");
        chatButton.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 10, 1, 1, new java.awt.Color(0, 0, 0)));
        chatButton.setBorderPainted(false);
        chatButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        chatButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        chatButton.setIconTextGap(23);
        chatButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chatButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelButtonsLayout = new javax.swing.GroupLayout(panelButtons);
        panelButtons.setLayout(panelButtonsLayout);
        panelButtonsLayout.setHorizontalGroup(
            panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(updateButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(createButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(readButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(deleteButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelButtonsLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(inicioPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(68, 68, 68))
            .addComponent(chatButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelButtonsLayout.setVerticalGroup(
            panelButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelButtonsLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(inicioPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(createButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(readButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(chatButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        contenido.setBackground(new java.awt.Color(255, 255, 255));
        contenido.setPreferredSize(new java.awt.Dimension(774, 520));

        javax.swing.GroupLayout contenidoLayout = new javax.swing.GroupLayout(contenido);
        contenido.setLayout(contenidoLayout);
        contenidoLayout.setHorizontalGroup(
            contenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 774, Short.MAX_VALUE)
        );
        contenidoLayout.setVerticalGroup(
            contenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelButtons, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contenido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelFondoLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(contenido, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)))
                .addContainerGap())
        );

        themesMenu.setText("TemasFL");

        lightTButton.setText("Light");
        lightTButton.setSelected(true);
        lightTButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lightTButtonActionPerformed(evt);
            }
        });
        themesMenu.add(lightTButton);

        darkTButton.setText("Dark");
        darkTButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                darkTButtonActionPerformed(evt);
            }
        });
        themesMenu.add(darkTButton);

        darculaTButton.setText("Darcula");
        darculaTButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                darculaTButtonActionPerformed(evt);
            }
        });
        themesMenu.add(darculaTButton);

        intelliTButton.setText("Intelli");
        intelliTButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                intelliTButtonActionPerformed(evt);
            }
        });
        themesMenu.add(intelliTButton);

        themesMenuBar.add(themesMenu);

        setJMenuBar(themesMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1029, 583));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lightTButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lightTButtonActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatLightLaf());
                SwingUtilities.updateComponentTreeUI(this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(JFrameFlatLaf.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_lightTButtonActionPerformed

    private void darkTButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_darkTButtonActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatDarkLaf());
                SwingUtilities.updateComponentTreeUI(JFrameFlatLaf.this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(JFrameFlatLaf.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_darkTButtonActionPerformed


    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        mostrarPanel(new Actualizar());
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        mostrarPanel(new Eliminar());
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void createButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createButtonActionPerformed
        mostrarPanel(new añadir());
    }//GEN-LAST:event_createButtonActionPerformed

    private void darculaTButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_darculaTButtonActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatDarculaLaf());
                SwingUtilities.updateComponentTreeUI(JFrameFlatLaf.this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(JFrameFlatLaf.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_darculaTButtonActionPerformed

    private void intelliTButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_intelliTButtonActionPerformed
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatIntelliJLaf());
                SwingUtilities.updateComponentTreeUI(JFrameFlatLaf.this);
            } catch (UnsupportedLookAndFeelException ex) {
                Logger.getLogger(JFrameFlatLaf.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }//GEN-LAST:event_intelliTButtonActionPerformed

    private void inicioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioButtonActionPerformed
        mostrarPanel(new Inicio());
    }//GEN-LAST:event_inicioButtonActionPerformed

    private void readButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readButtonActionPerformed
        mostrarPanel(new buscarUsuario());
    }//GEN-LAST:event_readButtonActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void chatButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chatButtonActionPerformed
        mostrarPanel(new Chat());
    }//GEN-LAST:event_chatButtonActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton chatButton;
    private javax.swing.JPanel contenido;
    private javax.swing.JButton createButton;
    private javax.swing.JMenuItem darculaTButton;
    private javax.swing.JMenuItem darkTButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton inicioButton;
    private javax.swing.JPanel inicioPanel;
    private javax.swing.JMenuItem intelliTButton;
    private javax.swing.JButton jButton6;
    private javax.swing.JMenuItem lightTButton;
    private javax.swing.JPanel panelButtons;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JButton readButton;
    private javax.swing.JMenu themesMenu;
    private javax.swing.JMenuBar themesMenuBar;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
