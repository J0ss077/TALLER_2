package com.mycompany.interfaces;

import com.mycompany.models.Empleado;
import java.util.List;


public interface DAOempleado {
    
    public void registrar(Empleado empleado) throws Exception;

    public void eliminar(int cedula) throws Exception;

    public void modificar(Empleado empleado) throws Exception;

    public List<Empleado> listaEmpleados() throws Exception;
    
    public List<Empleado> listaEmpleadosCond(int cedula) throws Exception;
    
}
