package com.mycompany.interfaces;

import com.mycompany.models.Trabajo;
import java.util.List;

public interface DAOtrabajo {

    public void registrar(Trabajo trabajo) throws Exception;

    public void eliminar(int cedula_empleado) throws Exception;

    public void modificar(Trabajo trabajo) throws Exception;

    public List<Trabajo> listatrabajos() throws Exception;

}
