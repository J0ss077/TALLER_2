package com.mycompany.interfazbasededatos;


public class InterfazBaseDeDatos {

    public static void main(String[] args) {
        JFrameFlatLaf f = new JFrameFlatLaf();       
        f.setVisible(true);
    }
}
