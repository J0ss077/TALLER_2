package com.mycompany.interfazbasededatos;

import com.mycompany.conection.conexion;
import com.mycompany.interfaces.DAOempleado;
import com.mycompany.models.Empleado;
import com.mycompany.models.Trabajo;
import com.mysql.cj.protocol.Resultset;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOempleadoImpl extends conexion implements DAOempleado {

    @Override
    public void registrar(Empleado empleado) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("INSERT INTO empleados(cedula, nombre, apellido, correo) VALUES(?, ?, ?, ?);");
            st.setInt(1, empleado.getCedula());
            st.setString(2, empleado.getNombre());
            st.setString(3, empleado.getApellido());
            st.setString(4, empleado.getCorreo());
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int cedula) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("DELETE FROM empleados WHERE cedula = ?;");
            st.setInt(1, cedula);
            st.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Empleado empleado) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("UPDATE empleados SET nombre = ?, apellido = ?, correo = ? WHERE cedula = ?;");

            st.setString(1, empleado.getNombre());
            st.setString(2, empleado.getApellido());
            st.setString(3, empleado.getCorreo());
            st.setInt(4, empleado.getCedula());

            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Empleado> listaEmpleados() throws Exception {
        List<Empleado> listaBuscarEmp = null;

        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement("SELECT empleados.cedula, empleados.nombre, empleados.apellido, empleados.correo, trabajo.puesto, trabajo.salario FROM empleados JOIN trabajo ON empleados.cedula = trabajo.cedula_empleado;");

            listaBuscarEmp = new ArrayList<>();
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Empleado empleado = new Empleado();
                Trabajo trabajo = new Trabajo();

                empleado.setCedula(rs.getInt("cedula"));
                empleado.setNombre(rs.getString("nombre"));
                empleado.setApellido(rs.getString("apellido"));
                empleado.setCorreo(rs.getString("correo"));
                trabajo.setSalario(rs.getInt("salario"));
                trabajo.setPuesto(rs.getString("puesto"));

                empleado.setTrabajo(trabajo);
                listaBuscarEmp.add(empleado);
            }
            rs.close();
            st.close();

        } catch (SQLException e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return listaBuscarEmp;
    }

    @Override
    public List<Empleado> listaEmpleadosCond(int cedula) throws Exception {
        List<Empleado> listaBuscarEmp = new ArrayList<>();

        try {
            this.conectar();
            PreparedStatement st = this.conexionSQL.prepareStatement(
                    "SELECT empleados.cedula, empleados.nombre, empleados.apellido, empleados.correo, "
                    + "trabajo.puesto, trabajo.salario FROM empleados "
                    + "JOIN trabajo ON empleados.cedula = trabajo.cedula_empleado "
                    + "WHERE empleados.cedula = ?;"
            );

            Empleado empleado = new Empleado();
            Trabajo trabajo = new Trabajo();

            st.setInt(1, cedula);
            ResultSet rs = st.executeQuery();

            while (rs.next()) {

                empleado.setCedula(rs.getInt("cedula"));
                empleado.setNombre(rs.getString("nombre"));
                empleado.setApellido(rs.getString("apellido"));
                empleado.setCorreo(rs.getString("correo"));
                trabajo.setPuesto(rs.getString("puesto"));
                trabajo.setSalario(rs.getInt("salario"));

                empleado.setTrabajo(trabajo);
                listaBuscarEmp.add(empleado);
            }

            rs.close();
            st.close();
        } catch (SQLException e) {
            throw e;
        } finally {
            this.Cerrar();
        }

        return listaBuscarEmp;
    }
}
