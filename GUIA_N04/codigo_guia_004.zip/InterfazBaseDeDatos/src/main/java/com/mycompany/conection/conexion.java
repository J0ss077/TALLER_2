package com.mycompany.conection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class conexion {

    protected Connection conexionSQL;
    private final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private final String DB_URL = "jdbc:mysql://localhost/empresa";
    private final String USER = "root";
    private final String PASS = "iKolomolo138.";

    public void conectar() {
        try {
            conexionSQL = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Cerrar() throws SQLException {
        if (conexionSQL != null) {
            if (conexionSQL.isClosed()) {
                conexionSQL.close();
            }
        }
    }
}
