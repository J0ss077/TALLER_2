/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_001;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author Joss077
 */
public class Matrix {
    
    public final int rows;
    public final int cols;
    public final int[][] data;

    public Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = new int[rows][cols];
    }

    public Matrix(int rows, int cols, boolean initializeRandom) {
        this(rows, cols);
        if (initializeRandom) {
            Random random = new Random();
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    data[i][j] = random.nextInt(100);
                }
            }
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Matrix matrix = (Matrix) o;
        return rows == matrix.rows &&
               cols == matrix.cols &&
               Arrays.deepEquals(data, matrix.data);
    }
}
