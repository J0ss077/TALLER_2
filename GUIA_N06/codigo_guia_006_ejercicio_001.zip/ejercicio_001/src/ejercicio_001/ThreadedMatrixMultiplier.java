/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_001;

/**
 *
 * @author Joss077
 */
public class ThreadedMatrixMultiplier {
    
    private static final int NUM_THREADS = 4;

    public static Matrix multiply(Matrix a, Matrix b) {
        if (a.cols != b.rows) {
            throw new IllegalArgumentException("Columns of A must match rows of B");
        }

        int aRows = a.rows;
        int bCols = b.cols;

        Matrix result = new Matrix(aRows, bCols);

        int rowsPerThread = aRows / NUM_THREADS;
        Thread[] threads = new Thread[NUM_THREADS];

        for (int t = 0; t < NUM_THREADS; t++) {
            int startRow = t * rowsPerThread;
            int endRow = (t == NUM_THREADS - 1) ? aRows - 1 : startRow + rowsPerThread - 1;

            threads[t] = new Thread(new MultiplicationTask(a, b, result, startRow, endRow));
            threads[t].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    private static class MultiplicationTask implements Runnable {
        private final Matrix a;
        private final Matrix b;
        private final Matrix result;
        private final int startRow;
        private final int endRow;

        public MultiplicationTask(Matrix a, Matrix b, Matrix result, int startRow, int endRow) {
            this.a = a;
            this.b = b;
            this.result = result;
            this.startRow = startRow;
            this.endRow = endRow;
        }

        @Override
        public void run() {
            int aCols = a.cols;
            int bCols = b.cols;

            for (int i = startRow; i <= endRow; i++) {
                for (int j = 0; j < bCols; j++) {
                    int sum = 0;
                    for (int k = 0; k < aCols; k++) {
                        sum += a.data[i][k] * b.data[k][j];
                    }
                    result.data[i][j] = sum;
                }
            }
        }
    }
}
