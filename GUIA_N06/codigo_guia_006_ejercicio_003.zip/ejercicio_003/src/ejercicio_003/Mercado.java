package ejercicio_003;

import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Mercado {

    public static void main(String[] args) throws InterruptedException {

        //creamos variables y lista
        boolean salir = true;
        int conswitch;
        Scanner sc = new Scanner(System.in);

        //Lista segura para los productos
        BlockingQueue<Productos> colaMercado = new LinkedBlockingQueue<>();
        //Objeto de cajero para inicializar la metodo de start
        Cajero cajero = new Cajero(colaMercado);

        cajero.start();

        System.out.println("Bienvenido a su supermercado de confianza");
        //Creamos el do while con el switch adentro
        do {
            System.out.println("""
                               +----------------------------------+
                               |       MENU DE SUPERMERCADO       |
                               +----------------------------------+
                               |      SELECCIONE EL PRODUCTO      |
                               +----------------------------------+
                               |  1. Leche                        |
                               |  2. Pan                          |
                               |  3. Tomates                      |
                               |  4. Huevos                       |
                               |  5. Sal  refinada                |
                               |  6. Salir                        |
                               +----------------------------------+
                               """);
            conswitch = sc.nextInt();
            System.out.println("");

            //switch para mercado
            switch (conswitch) {

                case 1 -> {
                    colaMercado.put(new Productos("Leche", 7));
                    System.out.println("Producto agregado con exito!!!");
                    System.out.println("");
                }
                case 2 -> {
                    colaMercado.put(new Productos("Pan", 3));
                    System.out.println("Producto agregado con exito!!!");
                    System.out.println("");
                }
                case 3 -> {
                    colaMercado.put(new Productos("Tomates", 5));
                    System.out.println("Producto agregado con exito!!!");
                    System.out.println("");
                }
                case 4 -> {
                    colaMercado.put(new Productos("Huevos", 10));
                    System.out.println("Producto agregado con exito!!!");
                    System.out.println("");
                }
                case 5 -> {
                    colaMercado.put(new Productos("Sal", 1));
                    System.out.println("Producto agregado con exito!!!");
                    System.out.println("");
                }
                case 6 -> {
                    //Producto para salir
                    colaMercado.put(new Productos("FIN", 0));
                    System.out.println("");
                    salir = false;
                }
                default ->
                    throw new AssertionError();
            }

        } while (salir != false);

        cajero.join(); // Esperar a que termine el cajero
        System.out.println("Cajero Cerrado");
    }

}
