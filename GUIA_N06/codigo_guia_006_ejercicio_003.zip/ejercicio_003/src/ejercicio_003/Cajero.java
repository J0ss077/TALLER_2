package ejercicio_003;

import java.util.concurrent.BlockingQueue;

public class Cajero extends Thread {

// Cola segura para hilos, donde se reciben productos
    private BlockingQueue<Productos> productos;

    public Cajero(BlockingQueue<Productos> productos) {
        this.productos = productos;
    }

    @Override
    public void run() {
        int precioTOT = 0;

        try {
            while (true) {
                // Espera hasta que haya un producto disponible
                Productos producto = productos.take();

                // Se crea un producto llamado fin, para finalizar
                if (producto.nombre.equals("FIN")) {
                    break;
                }

                // Se espera un segundo por escaneo
                Thread.sleep(1000);
                System.out.println("Producto: " + producto.nombre + " | Precio: " + producto.precio + "$");
                precioTOT += producto.precio;

                // Muestra el total actual
                System.out.println("Total: " + precioTOT + "$\n");
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Mensaje final luego de procesar todos los productos
        System.out.println("Precio total a pagar " + precioTOT + "$");
        System.out.println("Gracias por comprar con nosotros :)");
    }
}
