package ejercicio_003;

public class Productos {

    String nombre;
    int precio;

    public Productos(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

}
