package ejercicio_004;

import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class numerosRDM extends Thread {

    // Cola segura para hilos, donde se reciben productos
    private BlockingQueue<Integer> numerosRMDBQ;

    public numerosRDM(BlockingQueue<Integer> numerosRMDBQ) {
        this.numerosRMDBQ = numerosRMDBQ;
    }

    @Override
    public void run() {

        for (int i = 0; i < 20; i++) {
            int numero = (int) ((Math.random() * 100) + 1);
            try {
                numerosRMDBQ.put(numero);
            } catch (InterruptedException ex) {
                Logger.getLogger(numerosRDM.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("Numeros generados exitosamente");
        System.out.println("Calculando...");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(numerosRDM.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
