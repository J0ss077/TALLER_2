package ejercicio_004;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class OperacionSimple {

    public static void main(String[] args) {

        // Cola segura para hilos, donde se reciben productos
        BlockingQueue<Integer> numerosRMDBQ = new ArrayBlockingQueue<>(20);

        numerosRDM hilo1 = new numerosRDM(numerosRMDBQ);
        multiplicador hilo2 = new multiplicador(numerosRMDBQ);

        hilo1.start();
        hilo2.start();

    }

}
