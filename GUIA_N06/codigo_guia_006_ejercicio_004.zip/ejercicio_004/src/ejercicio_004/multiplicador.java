package ejercicio_004;

import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class multiplicador extends Thread {

    // Cola segura para hilos, donde se reciben productos
    private BlockingQueue<Integer> numerosRMDBQ;

    public multiplicador(BlockingQueue<Integer> numerosRMDBQ) {
        this.numerosRMDBQ = numerosRMDBQ;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            try {
                int numero = numerosRMDBQ.take();
                System.out.println((i + 1) + "." + "Numero: " + numero + "|Multipliado: " + (numero * 2));
            } catch (InterruptedException ex) {
                Logger.getLogger(multiplicador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
