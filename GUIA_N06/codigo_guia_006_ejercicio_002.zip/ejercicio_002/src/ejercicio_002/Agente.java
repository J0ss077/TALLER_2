/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_002;

import java.util.Queue;

/**
 *
 * @author Joss077
 */
public class Agente implements Runnable {
    
    private String nombre;
    private Queue<Llamada> colaLlamadas;

    public Agente(String nombre, Queue<Llamada> colaLlamadas) {
        this.nombre = nombre;
        this.colaLlamadas = colaLlamadas;
    }

    @Override
    public void run() {
        while (true) {
            Llamada llamada = null;
            synchronized (colaLlamadas) {
                while (colaLlamadas.isEmpty()) {
                    try {
                        colaLlamadas.wait(); // Espera si no hay llamadas
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                llamada = colaLlamadas.poll();
            }
            if (llamada != null) {
                System.out.println(nombre + " inicia llamada " + llamada.getId() + " (Duracion: " + llamada.getDuracion() + "s)");
                try {
                    Thread.sleep(llamada.getDuracion() * 1000); // Simula atención
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(nombre + " finaliza llamada " + llamada.getId());
            }
        }
    }
}
