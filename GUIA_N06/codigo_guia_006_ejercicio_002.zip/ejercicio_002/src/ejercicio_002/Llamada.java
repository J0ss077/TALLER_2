/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_002;

/**
 *
 * @author Joss077
 */
public class Llamada {
    
    private int id;
    private int duracion;

    public Llamada(int id, int duracion) {
        this.id = id;
        this.duracion = duracion;
    }

    public int getId() {
        return id;
    }

    public int getDuracion() {
        return duracion;
    }
}
